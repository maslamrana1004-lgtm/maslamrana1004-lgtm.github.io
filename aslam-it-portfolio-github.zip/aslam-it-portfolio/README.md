# Muhammad Aslam — IT Certifications Portfolio

## Publish on GitHub Pages
1. Create a new GitHub repository (for example, `aslam-it-portfolio`).
2. Upload **all contents** of this folder, keeping the `images` folder beside `index.html`.
3. Open the repository's **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then Save.
6. After GitHub publishes the site, open the Pages URL shown in Settings → Pages.

The site is responsive and certificate images can be clicked to enlarge.
